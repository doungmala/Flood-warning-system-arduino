const int pingPin = 13;
int inPin = 12;
/*เมื่อน้ำถึงระดับเซนเซอร์ จะมีเสียงบัซเซอร์ดังขึ้น */
#define WATER_SENSOR A0 // ขา SIG ต่อกับขา D3 ของ Arduino
#define SIGNAL_PIN A5

void setup() {
  Serial.begin(9600);
  pinMode(2, OUTPUT); 
  pinMode(3, OUTPUT);
  pinMode(4, OUTPUT);
  digitalWrite(2, HIGH);
  delay(500);
  digitalWrite(3, HIGH);
  delay(500);
  digitalWrite(4, HIGH);
  delay(500);
}
 
void loop()
{
  int Watervalue = analogRead(SIGNAL_PIN); // read the analog value from sensor

  Serial.print("Water Sensor value: ");
  Serial.println(Watervalue);

  delay(1000);
  
  // read the input on analog pin 0:
  int sensorValue = analogRead(A0);
  // print out the value you read:
  Serial.print("Rain Sensor value: ");
  Serial.println(sensorValue);
  delay(1000);        // delay in between reads for stability
  
  long duration, cm;
  pinMode(pingPin, OUTPUT);
  digitalWrite(pingPin, LOW);
  delayMicroseconds(2);
  digitalWrite(pingPin, HIGH);
  delayMicroseconds(5);
  digitalWrite(pingPin, LOW);
  pinMode(inPin, INPUT);
  duration = pulseIn(inPin, HIGH);
   
  cm = microsecondsToCentimeters(duration);

  Serial.print("Ultrasonics Sensor value: ");
  Serial.print(cm);
  Serial.print("cm");
  Serial.println();
  delay(100);

  
  //if (cm <=20 && Watervalue <=100 && sensorValue <=100) {
  if (cm <=50) { 
    Serial.println("light is on");
    digitalWrite(4, LOW);
    delay(500);
    digitalWrite(2, HIGH);
    delay(500);
    digitalWrite(3, HIGH);
    delay(500);
  }
  else{
    Serial.println("light is off");
    digitalWrite(2, HIGH);
    delay(500);
    digitalWrite(3, HIGH);
    delay(500);
    digitalWrite(4, HIGH);
    delay(500);
  }
  
}
 
long microsecondsToCentimeters(long microseconds)
{
  // The speed of sound is 340 m/s or 29 microseconds per centimeter.
  // The ping travels out and back, so to find the distance of the
  // object we take half of the distance travelled.
  return microseconds / 29 / 2;
}
