int relay_pin = 3;
void setup(){
pinMode(relay_pin,OUTPUT);
}
void loop(){
digitalWrite(relay_pin,LOW);
delay(100);
}
