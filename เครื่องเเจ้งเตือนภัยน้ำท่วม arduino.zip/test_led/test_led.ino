#include <ESP8266WiFi.h> 
#include <Wire.h>
#include <SPI.h>
#include <MySQL_Generic.h>

int Relay1 = D1; // กำหนดขาใช้งาน

void setup()
{
  pinMode(Relay1, OUTPUT); // กำหนดขาทำหน้าที่ให้ขา D0 เป็น OUTPUT
  digitalWrite(Relay1, HIGH);

}
void loop()
{
  digitalWrite(Relay1, LOW); // ส่งให้ไฟติด
  delay(1000); // ดีเลย์ 1000ms

}
